/** @namespace
    @borrows trstr as trim
*/
var util = {
    "trim": trstr
};

/** 
    Remove whitespace from around a string.
    @param {string} str
 */
function trstr(str) {
}

