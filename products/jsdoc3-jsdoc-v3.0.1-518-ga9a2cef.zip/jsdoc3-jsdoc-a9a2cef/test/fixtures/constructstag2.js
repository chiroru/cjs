Classify('Menu', 
    /**
        @constructs Menu
        @param items
     */
    function (items) {
        
    },
    {
        /**
            @memberof Menu#
         */
        show: function(){
        }
    }
);
