/** @constructor
    @copyright (c) 2011 Michael Mathews
*/
function Thingy() {
    
}