// Used to test jsdoc/util/include
var myGlobal = require('jsdoc/util/global');
myGlobal.__globalForIncludeTest__++;
