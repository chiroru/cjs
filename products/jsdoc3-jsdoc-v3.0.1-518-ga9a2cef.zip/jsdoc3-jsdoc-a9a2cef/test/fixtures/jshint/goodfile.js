var foo = 0;
