/** @license GPL v2 */
var x;
