/** document me */
var tools = {
    /** document me */
    serialiser: {
        /** document me */
        value: ''
    }
};
