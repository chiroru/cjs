/**
* @constructor
* @private
*/
function Foo() {

    /** document me */
    this.bar = 1;
}


