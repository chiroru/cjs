/** A function.
 * @todo something
 * @todo something else
 */
function x() {
}
