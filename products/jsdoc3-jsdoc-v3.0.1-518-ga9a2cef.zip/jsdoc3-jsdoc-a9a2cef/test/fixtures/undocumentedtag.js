/** Undocumented doclet.
 * @undocumented */
var x;
